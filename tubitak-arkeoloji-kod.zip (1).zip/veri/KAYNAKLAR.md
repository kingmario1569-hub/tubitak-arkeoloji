# Veri kaynakları

Her indirilen dosya için bir satır doldurun. Jüri "Bu veri nereden geldi?" diye sorduğunda cevap bu tablodur.

| Dosya (veri/ham/...) | Kaynak ve bağlantı | İndirme tarihi | Lisans | Not |
|---|---|---|---|---|
| (DEM) | Copernicus GLO-30, AWS açık veri: https://copernicus-dem-30m.s3.amazonaws.com/ | betik çalıştırıldığında otomatik | Copernicus DEM lisansı (ücretsiz, atıf gerekli) | İndirme gerekmez |
| hydrorivers/... | HydroRIVERS v1.0, https://www.hydrosheds.org/ | | | |
| hydrolakes/... | HydroLAKES v1.0, https://www.hydrosheds.org/ | | | |
| osm/... | Geofabrik Türkiye, https://download.geofabrik.de/europe/turkey.html | | ODbL | Önyargı değişkenleri için |
| aluvyon.gpkg | MTA 1:500.000 jeoloji haritasından ayıklandı | | | Nasıl ayıklandığını yazın |
| madenler.csv | | | | Her satırda kaynak sütunu dolu olmalı |
| obsidiyen.csv | | | | |
| gecit_koridorlari.gpkg | QGIS'te üretildi (yöntemi yazın) | | | |
